﻿using UnityEngine;
using System.Collections;
using UnityEngine.AI;

namespace CompleteProject
{
    public class EnemyMovement : MonoBehaviour
    {
		Transform player;               // 플레이어의 위치에 대한 참조
		//PlayerHealth playerHealth;      // 플레이어의 체력에 대한 참조
		//EnemyHealth enemyHealth;        // 적의 체력에 대한 참조
		//UnityEngine.AI.
		NavMeshAgent nav;               // nav mesh agent에 대한 참조.


        void Awake ()
        {
			// 여기서 참조를 설정
            player = GameObject.FindGameObjectWithTag ("Player").transform;
            //playerHealth = player.GetComponent <PlayerHealth> ();
            //enemyHealth = GetComponent <EnemyHealth> ();
            nav = GetComponent <NavMeshAgent> ();
        }


        void Update ()
        {
			// 적이나 플레이어가 체력을 잃은 경우,
			//if(enemyHealth.currentHealth > 0 && playerHealth.currentHealth > 0 )
            //{
				// nav mesh agent의 대상을 플레이어로 설정
               nav.SetDestination (player.position);
            //}
      // 그렇지 않은 경우,
           //else
            //{
				// nav mesh agent를 비활성화
                //nav.enabled = false;
            //}
        }
    }
}